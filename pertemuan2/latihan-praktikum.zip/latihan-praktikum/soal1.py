stok = [15, 50, 30, 25,40]

stok.append(100)
stok.insert(2, 75)
stok.sort(reverse = True)

rata-rata = stok\7

print(stok)