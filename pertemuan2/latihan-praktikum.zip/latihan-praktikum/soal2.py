barang = ("B001", "Laptop Gaming", 15000000 )

barang[3] = 14000000 #tidak bisa, karena tuple tidak bisa diubah

(kode, nama, harga) = barang 


